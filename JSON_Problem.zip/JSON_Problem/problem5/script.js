var array = [["make", "Ford"], ["model", "Mustang"], ["year", 1964]];

function fromListToObject(arr){

    let object={}
    for(let i in arr)
    {
        object[arr[i][0]]=arr[i][1]
    }
    return object
}

var output=fromListToObject(array)

console.log(output)