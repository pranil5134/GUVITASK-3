var object = {name: "RajiniKanth", age: 33, hasPets : false};

function printAllValues()
{
    var result=[];
   
        result=Object.values(object)
   
     

    return (result)
}
var print_out=printAllValues();

console.log(print_out);

function printAllKeys()
{
    var result=[];
   
        result=Object.keys(object)
   
     

    return (result)
}
var print_out=printAllKeys();

console.log(print_out);