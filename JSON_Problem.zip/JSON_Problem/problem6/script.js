var array = [[["firstName", "Vasanth"], ["lastName", "Raja"], ["age", 24], ["role", "JSWizard"]], [["firstName", "Sri"], ["lastName", "Devi"], ["age", 28], ["role", "Coder"]]];


function TransformEmployeeData(arr){
 var employeelist=[]
   for(let i in arr)
   {       var obj={};
       //console.log(arr[i])
       for(let j in arr[i])
       {
           //console.log(arr[i][j][1])
           //console.log(obj[arr[j][0]],arr[j][1])
          obj[arr[i][j][0]]=arr[i][j][1]
       }
       employeelist.push(obj)
   }

   return employeelist;
}



let obj=TransformEmployeeData(array)

console.log(obj)