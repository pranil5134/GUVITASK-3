var cat = {
    name: "Fluffy",
    activities: ['play', 'eat cat food'],
    catFriends: [
    {
    name: 'bar',
    activities: ['be grumpy', 'eat bread omblet'],
    weight: 8,
    furcolor: 'white'
    }, 
    {
    name: 'foo',
    activities: ['sleep', 'pre-sleep naps'],
    weight: 3
    }
    ]
   }
  
///Add height and weight to Fluffy
console.log('1.Added height and weight to Fluffy')
cat.height= 1
cat.weight=3

//Fluffy name is spelled wrongly. Update it to Fluffyy
console.log('2.Fluffy name is spelled wrongly. Updated it to Fluffyy')
cat.name="Fluffyy"

//List all the activities of Fluffyy’s catFriends.
console.log("3. All Activites Of Cat Friends")
for(let i in cat.catFriends)
{
    for(let j in cat.catFriends[i].activities)
    {
        console.log(cat.catFriends[i].activities[j])
    }
    
}
console.log("4. Name of All fluffyy's friend")
//Print the catFriends names.
for(let i in cat.catFriends)
{
    console.log(cat.catFriends[i].name)
}
///Print the total weight of catFriends
console.log("5. Print the total weight of catFriends")
let totalweight=0;
for(let i in cat.catFriends)
{
    totalweight=totalweight+cat.catFriends[i].weight
    
}
console.log("total weight of catFriends= ", totalweight)
//Print the total activities of all cats (op:6)
console.log("6. Print the total activities of all cats (op:6)")

//Add 2 more activities to bar & foo cats
var additional_foo_activity=["Hunting Prey","Watching TV"]
var additional_bar_activity=["After-spleep nap","staring at wall"]
console.log("7. Add 2 more activities to bar & foo cats")
cat.catFriends[0].activities=cat.catFriends[0].activities.concat(additional_bar_activity)
cat.catFriends[1].activities=cat.catFriends[1].activities.concat(additional_foo_activity)
for(let i in cat.catFriends)
{
    for(let j in cat.catFriends[i].activities)
    {
        console.log(cat.catFriends[i].activities[j])
    }
    
}
//Update the fur color of bar
console.log("8 Update the fur color of bar")
cat.catFriends[0].furcolor="Grey"
//console.log(cat)
console.log("9 console.log(cat)")
console.log(cat)