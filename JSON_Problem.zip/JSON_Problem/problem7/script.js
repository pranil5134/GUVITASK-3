var expected = {foo: 5, bar: 6};
var actual = {foo: 5, bar: 6};

var expected1 = {foo: 5, bar: 6};
var actual1 = {foo: 6, bar: 5};



function assertObjectsEqual(exp,act)
{
    let actual_array=JSON.stringify(act)
    let expected_array=JSON.stringify(exp);
    if(actual_array==expected_array)
    {
        console.log("Passed")
    }
    else{
        console.log("FAILED","[My test] Expected",exp,"but got",act )
    }
}

assertObjectsEqual(expected,actual)
assertObjectsEqual(expected1,actual1)