var array = ["GUVI", "I", "am", "Geek"];

function transformFirstAndLast(){

    let obj={}
    let key=array[0]
    obj[key]=array[array.length-1]

    console.log(obj)

}

transformFirstAndLast()