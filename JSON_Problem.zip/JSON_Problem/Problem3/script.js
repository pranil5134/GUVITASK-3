var object = {name: "ISRO", age: 35, role: "Scientist"};

function convertObjectToList(){

    return Object.entries(object);
}

var output=convertObjectToList()

console.log(output)